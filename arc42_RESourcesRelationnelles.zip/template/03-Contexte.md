# 03 - Contexte (Template)

## Environnement du projet
Décrire le contexte global (secteur, acteurs, enjeux).

## Acteurs principaux
Lister les utilisateurs, clients et partenaires clés.

## Motivation et problème à résoudre
Expliquer les besoins, les problèmes ou opportunités justifiant le projet.

## Interfaces externes
Décrire les interactions avec d'autres systèmes ou acteurs externes.

