# 02 - Contraintes (Template)

## Contraintes techniques
Lister les contraintes liées aux technologies, à l’architecture ou à la compatibilité.

## Contraintes organisationnelles
Préciser les contraintes liées au planning, au budget, à la gouvernance, etc.

## Contraintes légales et réglementaires
Inclure les exigences comme le RGPD, normes de sécurité, accessibilité, etc.

## Contraintes de qualité
Mentionner les exigences de performance, sécurité, ergonomie, accessibilité.

