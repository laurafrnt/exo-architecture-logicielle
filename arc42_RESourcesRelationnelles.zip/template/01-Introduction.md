# 01 - Introduction (Template)

## Objectif du document
Décrire le contexte général du projet, ses objectifs et les motivations principales.

## Objectifs du système
- Identifier les buts clés du système.
- Expliquer la valeur ajoutée pour les utilisateurs et l'organisation.

## Parties prenantes
Lister les principales parties prenantes internes et externes :
- Interne : direction, chef de projet, équipes techniques, etc.
- Externe : clients, utilisateurs finaux, fournisseurs, partenaires, etc.

## Vue d’ensemble du système
Donner une vision synthétique du système ou produit à développer.

## Portée du projet
Préciser ce qui est inclus et exclu dans le périmètre du projet.

